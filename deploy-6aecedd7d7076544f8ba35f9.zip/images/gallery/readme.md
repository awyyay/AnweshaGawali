Put gallery photos (.jpg/.png/.webp) and videos (.mp4/.webm) here, then list them in /gallery.js with a title and description. Cards whose file is missing are hidden automatically.
Keep videos short and under ~20 MB so the page stays fast.
